package bookcare;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;

import java.time.Month;
import java.time.Year;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
@DisplayName("<= BookcareShelf Specification =>")
@ExtendWith(BooksParameterResolver.class)

public class BookcareShelfSpec extends DBConnectionPool {

    private BookcareShelf shelf;

    //ten books
    private Book eltaTherapy;
    private Book dhcFaceWash;
    private Book dhcCleansingFoam;
    private Book skinceuticalsCSerum;
    private Book eltaMDEssenceToner;
    private Book supergoopMineralLotion;
    private Book ceraveSunscreenStick;
    private Book glytoneBrightening;
    private Book skinmedicaExfoliator;
    private Book ceraveMoisturizingCream;

    // First Test Constructor
    private BookcareShelfSpec (TestInfo testInfo){
        System.out.println("Working on test "+ testInfo.getDisplayName());
    }

    @BeforeEach
    void init(Map<String, Book> books){
        shelf = new BookcareShelf();

        this.eltaTherapy = books.get("EltaMD PM Therapy");
        this.dhcFaceWash = books.get("DHC Face Wash");
        this.dhcCleansingFoam = books.get("DHC Cleansing Foam");
        this.skinceuticalsCSerum = books.get("SkinCeuticals C E Ferulic");
        this.eltaMDEssenceToner = books.get("EltaMD Skin Recovery Essence Toner");
        this.supergoopMineralLotion = books.get("Supergoop! Mineral Lotion SPF50");
        this.ceraveSunscreenStick = books.get("CeraVe Sunscreen Stick SPF50");
        this.glytoneBrightening = books.get("Glytone Enhance Brightening Complex");
        this.skinmedicaExfoliator = books.get("SkinMedica AHA/BHA Exfoliator");
        this.ceraveMoisturizingCream = books.get("CeraVe Moisturizing Cream");
        
        System.out.println("<= Shelf is initialized. =>");
    }

    @Nested
    @DisplayName("Bookcare Shelf is Empty")
    class isEmpty{

        @Test
        @DisplayName("when no book is added to it")
        public void emptyBookcareShelfWhenNoBookAdded(){
            List <Book> books = shelf.books();
            assertTrue (books.isEmpty(), () -> "Bookcare Shelf should be empty.");
        }

        @Test
        @DisplayName("when add is called without books")
        void emptyBookcareShelfWhenAddIsCalledWithoutBooks(){
            shelf.add();
            List<Book> books = shelf.books();
            assertTrue(books.isEmpty(), ()->"Bookcare shelf should be empty." );
        }
    }

    @Nested
    @DisplayName("after adding books")

    class BooksAreAdded{
        //Test when multiple books are added
        @DisplayName("When five books are added in the Book shelf.")
        @Test
        void bookShelfContainsFiveBooksWhenFiveBooksAdded() {
            shelf.add(eltaMDEssenceToner, eltaTherapy, ceraveMoisturizingCream, skinceuticalsCSerum, supergoopMineralLotion);
            List<Book> Books = shelf.books();
            assertEquals(5, Books.size(), () -> "BookShelf should have five books.");
        }

        @DisplayName("Books returned from bookcare shelf is immutable for client.")
        @Test
        void booksReturnedFromBookcareShelfIsImmutableForClient(){
            shelf.add(eltaMDEssenceToner, eltaTherapy, ceraveMoisturizingCream, skinceuticalsCSerum, supergoopMineralLotion);
            List<Book> Books = shelf.books();
            try{
                Books.add(ceraveSunscreenStick);
                fail(() -> "Should not be able to add book to Bookcare shelf");
            } catch(Exception e){
                assertTrue(e instanceof UnsupportedOperationException, ()-> "Should throw UnsupportedOperationException.");
            }
        }
    }

    @Nested
    @DisplayName("is arranged")

    class IsArranged{

        // Test Case to arrange the books on certain criteria
        @DisplayName("Arranging the Books")
        @Test
        void bookcareShelfArrangedByBookName(){
            shelf.add(eltaTherapy, ceraveMoisturizingCream, skinceuticalsCSerum, supergoopMineralLotion,dhcCleansingFoam);
            List <Book> books = shelf.arrange();
            assertEquals(asList(ceraveMoisturizingCream, dhcCleansingFoam, eltaTherapy, skinceuticalsCSerum,supergoopMineralLotion), //expected value
                    books, //actual/real value
                    ()->"Books in a bookshelf should be arranged by name"); //error message when actual and expected does not match
        }

        @DisplayName("Books in Bookcare shelf retain their order after calling arrange() method." )
        @Test
        void booksInBookcareShelfAreInInsertionOrderAfterCallingArrange(){
            shelf.add(supergoopMineralLotion, dhcCleansingFoam, eltaTherapy, ceraveMoisturizingCream, skinceuticalsCSerum);
            shelf.arrange();
            List<Book> books = shelf.books();
            assertEquals(asList(supergoopMineralLotion, dhcCleansingFoam, eltaTherapy, ceraveMoisturizingCream, skinceuticalsCSerum),
                    books,
                    () -> "Books in Bookcare shelf are in inserted order");
        }

        @DisplayName("Bookcare shelf can be arranged by user provided criteria. Name descending")
        @Test
        void bookcareShelfArrangedByUserDescending(){
            shelf.add(supergoopMineralLotion, dhcCleansingFoam, eltaTherapy, ceraveMoisturizingCream, skinceuticalsCSerum);
            List <Book> books = shelf.arrange(Comparator.<Book>naturalOrder().reversed());
            assertEquals(asList(supergoopMineralLotion, skinceuticalsCSerum,eltaTherapy, dhcCleansingFoam,ceraveMoisturizingCream), books, () -> "Books in a Bookcare shelf are arranged in a descending order"+ "of Book name");
        }

//        @DisplayName("Skincare shelf can be arranged by user provided criteria. Price ascending")
//        @Test
//        void skincareShelfArrangedByPriceAscending(){
//            shelf.add(supergoopMineralLotion, dhcCleansingFoam, eltaTherapy, ceraveMoisturizingCream, skinceuticalsCSerum );
//            List <Product> Products = shelf.arrange();
//            assertEquals(asList(codeComplete, effectiveJava, theManOnTheMoon), Books, () -> "Books in a Bookcare Shelf are arranged in a descending order"+ "of Book name");
//        }

        @DisplayName("Bookcare Shelf can be arranged by published date. Ascending")
        @Test
        void bookcareShelfArrangedByPublishedDate(){
            shelf.add(supergoopMineralLotion, dhcCleansingFoam, eltaTherapy, ceraveMoisturizingCream, skinceuticalsCSerum );
            List <Book> Books = shelf.arrange((b1, b2) -> b1.getPublishedDate().compareTo(b2.getPublishedDate()));
            assertEquals(asList(eltaTherapy, ceraveMoisturizingCream, dhcCleansingFoam,skinceuticalsCSerum, supergoopMineralLotion), Books, ()-> "Books in a Bookcare shelf are arranged by the Book published date in ascending order.");
        }

        //AssertJ example
//        @DisplayName("Books are arranged by title")
//        @Test
//        void ProductshelfArrangedByUserAssertJ(){
//            shelf.add(effectiveJava, codeComplete, theManOnTheMoon );
//            Comparator<Book> reversed_criteria = Comparator.<Book>naturalOrder().reversed();
//            List <Book> Books = shelf.arrange(reversed_criteria);
//            assertThat(Books).isSortedAccordingTo(reversed_criteria);
//        }
    }

    @Nested
    @DisplayName("is Grouped")

    class IsGrouped{

        @DisplayName("Books inside skincare shelf are grouped by published year")
        @Test
        void groupBookInsideBookcareShelfByExpiryYear(){
            shelf.add(skinmedicaExfoliator,dhcFaceWash,ceraveSunscreenStick,glytoneBrightening);
            Map<Year, List<Book>> booksByPublishedYear = shelf.groupByPublishedYear();
            assertThat(booksByPublishedYear)
                    .containsKey(Year.of(2023))
                    .containsValues(Arrays.asList(skinmedicaExfoliator, dhcFaceWash));
            assertThat(booksByPublishedYear).containsKey(Year.of(2024)).containsValues(singletonList(ceraveSunscreenStick));
            assertThat(booksByPublishedYear). containsKey(Year.of(2022)).containsValues(singletonList(glytoneBrightening));
        }

        @Test
        @DisplayName("Books inside bookcare shelf are grouped according to user" +"provided criteria(group by brand name)")
        void groupBooksByUserProvidedCriteria() {
            shelf.add(skinmedicaExfoliator,dhcFaceWash,dhcCleansingFoam, ceraveSunscreenStick, ceraveMoisturizingCream, glytoneBrightening);
            Map<String, List<Book>> booksByBrand = shelf.groupBy(Book::getBrand);
            assertThat(booksByBrand)
                    .containsKey("SkinMedica")
                    .containsValues(singletonList(skinmedicaExfoliator));
            assertThat(booksByBrand)
                    .containsKey("CeraVe")
                    .containsValues(Arrays.asList(ceraveSunscreenStick, ceraveMoisturizingCream));
            assertThat(booksByBrand)
                    .containsKey("Glytone")
                    .containsValues(singletonList(glytoneBrightening));
        }

        @Test
        @DisplayName("Books inside bookcare shelf are grouped according to user" +" provided criteria(group by published month)")
        void groupBooksByPublishedMonth(){
            shelf.add(supergoopMineralLotion,eltaTherapy,dhcCleansingFoam, ceraveSunscreenStick, ceraveMoisturizingCream, glytoneBrightening, skinceuticalsCSerum);

            Map<Month, List<Book>> booksByPublishedMonth = shelf.groupByPublishedMonth();
            assertThat(booksByPublishedMonth).containsKey(Month.MAY).containsValues(singletonList(eltaTherapy));
            assertThat(booksByPublishedMonth).containsKey(Month.JUNE).containsValues(singletonList(supergoopMineralLotion));
            assertThat(booksByPublishedMonth).containsKey(Month.NOVEMBER).containsValues(singletonList(dhcCleansingFoam));
            assertThat(booksByPublishedMonth).containsKey(Month.DECEMBER).containsValues(singletonList(skinceuticalsCSerum));
        }

        @Test
        @DisplayName("Books inside bookcare shelf are grouped according to user" +" provided criteria(group by first alphabet of the book name)")
        void groupBooksByNameFirstAlphabet(){
            shelf.add(supergoopMineralLotion,eltaTherapy,dhcCleansingFoam, ceraveSunscreenStick, ceraveMoisturizingCream, glytoneBrightening);
            Map<String, List<Book>> BooksByFirstAlphabet = shelf.groupByFirstAlphabet() ;
            assertThat(BooksByFirstAlphabet).containsKey("C").containsValues(Arrays.asList(ceraveSunscreenStick, ceraveMoisturizingCream));
            assertThat(BooksByFirstAlphabet).containsKey("S").containsValues(singletonList(supergoopMineralLotion));
            assertThat(BooksByFirstAlphabet).containsKey("G").containsValues(singletonList(glytoneBrightening));
        }
    }






}
