package bookcare;

import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.api.extension.ParameterContext;
import org.junit.jupiter.api.extension.ParameterResolutionException;
import org.junit.jupiter.api.extension.ParameterResolver;

import java.lang.reflect.Parameter;
import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class BooksParameterResolver implements ParameterResolver {

    public BooksParameterResolver(){
    }

    @Override
    public boolean supportsParameter(final ParameterContext parameterContext, final ExtensionContext extensionContext) throws ParameterResolutionException {
        Parameter parameter = parameterContext.getParameter();
        return Objects.equals(parameter.getParameterizedType().getTypeName(),"java.util.Map<java.lang.String, bookcare.Book>");
    }

    @Override
    public Object resolveParameter(final ParameterContext parameterContext,final ExtensionContext extensionContext) throws ParameterResolutionException{
        //return Books;
        ExtensionContext.Store store = extensionContext.getStore(ExtensionContext.Namespace.create(Book.class));

        System.out.println(Book.class);

        return store.getOrComputeIfAbsent("Books",k -> getBooks() // <-- Default creator
        );
    }

    private Object getBooks() {
        Map<String, Book> Books = new HashMap<>();

        Books.put("EltaMD PM Therapy", new Book("EltaMD PM Therapy Facial Moisturizer", "Moisturizer", LocalDate.of(2022, Month.MAY, 8), 39, "dry skin", "Elta MD", "purchased"));

        Books.put("DHC Face Wash", new Book("DHC Face Wash", "Cleanser", LocalDate.of(2023, Month.MAY, 9), 13.5, "dry skin", "DHC", "purchased"));

        Books.put("DHC Cleansing Foam", new Book("DHC Cleansing Foam", "Cleanser", LocalDate.of(2022, Month.NOVEMBER, 7), 12, "oily skin", "DHC", "interested"));

        Books.put("SkinCeuticals C E Ferulic", new Book("SkinCeuticals C E Ferulic", "Serum", LocalDate.of(2022, Month.DECEMBER, 21), 169, "sensitive skin", "Skinceuticals", "purchased"));

        Books.put("EltaMD Skin Recovery Essence Toner", new Book("EltaMD Skin Recovery Essence Toner", "Toner", LocalDate.of(2023, Month.AUGUST, 17), 34, "combination skin", "EltaMD ", "purchased"));

        Books.put("Supergoop! Mineral Lotion SPF50", new Book("Supergoop! PLAY 100% Mineral Lotion SPF50", "Sunscreen", LocalDate.of(2023, Month.JUNE, 16), 36, "sensitive skin", "Supergoop!", "interested"));

        Books.put("CeraVe Sunscreen Stick SPF50", new Book("CeraVe Sunscreen Stick SPF 50", "Sunscreen", LocalDate.of(2024, Month.JULY, 19), 9, "combination skin", "CeraVe", "purchased"));

        Books.put("Glytone Enhance Brightening Complex", new Book("Glytone Enhance Brightening Complex", "Exfoliator", LocalDate.of(2022, Month.AUGUST, 11), 74, "oily skin", "Glytone", "purchased"));

        Books.put("SkinMedica AHA/BHA Exfoliator", new Book("SkinMedica AHA/BHA Exfoliator Cleanser", "Exfoliator", LocalDate.of(2023, Month.JANUARY, 12), 48, "combination skin", "SkinMedica", "purchased"));

        Books.put("CeraVe Moisturizing Cream", new Book("CeraVe Moisturizing Cream ", "Moisturizer", LocalDate.of(2022, Month.JULY, 1), 18.99, "dry skin", "CeraVe", "purchased"));

        return Books;
    }

}
