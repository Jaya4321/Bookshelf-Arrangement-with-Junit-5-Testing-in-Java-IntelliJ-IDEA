package bookcare;

import java.time.LocalDate;

public class Book implements Comparable<Book> {

    private final String name;
    private final String bookType;
    private final LocalDate publishedDate;
    private final double price;
    private final String authorName;
    private final String brand;
    private final String tag;

    public Book (String name, String bookType, LocalDate publishedDate, double price, String authorName, String brand, String tag ){
        this.name = name;
        this.bookType = bookType;
        this.publishedDate = publishedDate;
        this.price = price;
        this.authorName = authorName;
        this.brand = brand;
        this.tag = tag;

//        this.startedReadingOn = LocalDate.parse("1901-01-01");
//        this.finishedReadingOn = LocalDate.parse("1901-01-01");
    }

    // Get Methods

    public String getName(){
        return name;
    }

    public String getBookType(){
        return bookType;
    }

    public LocalDate getPublishedDate(){
        return publishedDate;
    }

    public double getPrice(){
        return price;
    }

    public String  getAuthorName(){
        return authorName;
    }

    public String getBrand(){
        return brand;
    }

    public String getTag() {
        return tag;
    }

    @Override

    public String toString() {

        return "Book{" +

                "name='" + name + '\'' +

                ", bookType ='" + bookType + '\'' +

                ", publishedDate=" + publishedDate + '\'' +

                ", price ='" + price + '\'' +

                ", authorName=" + authorName + '\'' +

                ", brand=" + brand + + '\'' +

                ", tag=" + tag +

                '}';
    }

    @Override
    public int compareTo(Book that) {
        return this.name.compareTo(that.name);
    }



}
