package bookcare;

import java.time.Month;
import java.time.Year;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.groupingBy;

public class BookcareShelf {

    private final List<Book> books = new ArrayList<>();

    public List<Book> books() {
        return Collections.unmodifiableList(books);
    }

    // method to add books to the shelf
    public void add(Book... booksToAdd){
        Arrays.stream(booksToAdd).forEach(books::add);
    }

    public List<Book> arrange() {
        return arrange(Comparator.naturalOrder());
    }
    public List<Book> arrange(Comparator<Book> criteria) {
        return books.stream().sorted(criteria).collect(Collectors.toList());
    }

    public <K> Map<K, List<Book>> groupBy(Function<Book, K> fx) {
        return books.stream().collect(groupingBy(fx));
    }

    public Map<Year, List<Book>> groupByPublishedYear() {
        return groupBy(Book->Year.of(Book.getPublishedDate().getYear()));
    }

    public Map<Month, List<Book>> groupByPublishedMonth() {
        return groupBy(Book->Month.of(Book.getPublishedDate().getMonthValue()));
    }

    public Map<String, List<Book>> groupByFirstAlphabet() {
        return groupBy(Book->String.valueOf(Book.getName().toUpperCase().charAt(0)));
    }
    
    


    
}
